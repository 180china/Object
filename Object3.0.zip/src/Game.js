
var GAME = GAME || {};
GAME.stageWidth=0;
GAME.stageHeight=0;
GAME.stage=null;
GAME.canvas=null;
GAME.renderer=null;
GAME.SCENE_IN="sceneIn";
GAME.SCENE_OUT="sceneOut";
GAME.SCENE_IN_COMPLETE="sceneInComplete";
GAME.SCENE_OUT_COMPLETE="sceneOutComplete";
GAME.ON_ENTER_FRAME="onEnterFrame";
GAME.retinaSupport=true;

GAME.Sound=null;
GAME.imageScale=1;

GAME.SoundConfig =
[
    {
		id : "bg",
		src : "sound/bg.ogg"
	}, 
	{
		id : "horse",
		src : "sound/horse.ogg"
	}
]
